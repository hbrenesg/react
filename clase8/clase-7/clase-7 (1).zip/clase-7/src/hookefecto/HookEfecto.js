import React, { useState, useEffect } from 'react';

export function HookEfecto() {

    const [contador, setContador] = useState(1);
    const [contadorb, setContadorB] = useState(2);

    // Similar a componentDidMount y componentDidUpdate: 
    useEffect(() => {
        // Actualiza el título del documento usando la API del browser
        // después del renderizado  
        document.title = `Click ${contador} veces ${contadorb}`;






        // Similar al componentWillUnmount
        return () => {
            document.title = "";





        };
    }, [contadorb]); // Solo se vuelve a ejecutar si "contador" ha cambiado

    return (
        <div>
            <p>Has clickeado {contador} veces</p>
            <button onClick={() => setContadorB(contadorb + 1)}>
                Clickeame!
            </button>

            {contadorb}
        </div>
    );
}
