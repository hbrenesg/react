import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
//import App from './App';
//import EnrutamientoAnidado from './enrutamientoanidado/EnrutamientoAnidado';
//import EnrutamientoNavegacion from './enrutamientonavegacion/EnrutamientoNavegacion';
//import EnrutamientoParametros from './enrutamientoparametros/EnrutamientoParametros';
//import { HookEstado } from './hookestado/HookEstado';
//import { HookEstadoMultiple } from './hookestadomultiple/HookEstadoMultiple';
//import { HookEfecto } from './hookefecto/HookEfecto';
import { Componente } from './componente/Componente';

import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Componente />
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
