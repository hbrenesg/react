import './Aviso.css';

function Aviso(props){
  return <h1>El nombre de la persona es {props.nombre} y su edad es {props.edad}. </h1>;
}

export default Aviso;
